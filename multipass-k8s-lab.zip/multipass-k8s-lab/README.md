# Multipass Kubernetes Lab

This package gives you a complete local lab with:

- 1 control-plane node (`k8s-master`)
- 1 worker node (`k8s-worker1`)
- 1 storage VM (`k8s-storage`) running NFS
- cloud-init files for all three VMs
- scripts to create and destroy the lab
- static NFS PV/PVC examples
- optional NFS dynamic provisioner manifests
- optional MetalLB templates

## Folder layout

- `cloud-init/` - cloud-init files for master, worker, and storage VMs
- `scripts/` - create/destroy scripts and cluster-init steps
- `k8s/` - static NFS PV/PVC and test pod examples
- `nfs-dynamic/` - dynamic NFS provisioner manifests
- `metallb/` - MetalLB installation note and IP pool template

## Quick start

```bash
cd scripts
chmod +x create-cluster.sh destroy-cluster.sh
./create-cluster.sh
```

Then follow `scripts/init-cluster.md`.

## Storage quick test

After the cluster is up:

1. Find the storage IP:

```bash
multipass info k8s-storage
```

2. Replace `REPLACE_WITH_NFS_SERVER_IP` in:
- `k8s/nfs-pv.yaml`
- `k8s/nfs-direct-pod.yaml`
- `nfs-dynamic/deployment.yaml`

3. Apply the static storage example:

```bash
kubectl apply -f k8s/nfs-pv.yaml
kubectl apply -f k8s/nfs-pvc.yaml
kubectl apply -f k8s/nfs-test-pod.yaml
```

## Optional: dynamic NFS provisioning

```bash
kubectl apply -f nfs-dynamic/rbac.yaml
kubectl apply -f nfs-dynamic/deployment.yaml
kubectl apply -f nfs-dynamic/storageclass.yaml
kubectl apply -f nfs-dynamic/test-pvc.yaml
```

## Optional: MetalLB

1. Install MetalLB using the official manifest command recorded in `metallb/metallb-native.yaml`
2. Replace `REPLACE_WITH_FREE_IP_RANGE` in `metallb/ipaddresspool.yaml`
3. Apply the IP pool:

```bash
kubectl apply -f metallb/ipaddresspool.yaml
```

## Cleanup

```bash
cd scripts
./destroy-cluster.sh
```
