#!/usr/bin/env bash
set -euo pipefail

multipass delete -p k8s-master k8s-worker1 k8s-storage || true
