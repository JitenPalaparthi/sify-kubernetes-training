# Initialize the Kubernetes cluster

## 1) Wait for cloud-init to finish

```bash
multipass exec k8s-master -- cloud-init status --wait
multipass exec k8s-worker1 -- cloud-init status --wait
multipass exec k8s-storage -- cloud-init status --wait
```

## 2) Initialize the control plane

```bash
multipass shell k8s-master
sudo kubeadm init --pod-network-cidr=10.244.0.0/16
```

## 3) Configure kubectl on the master

```bash
mkdir -p $HOME/.kube
sudo cp /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```

## 4) Install Flannel

```bash
kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml
```

## 5) Generate the join command

```bash
kubeadm token create --print-join-command
```

## 6) Join the worker node

Open a second terminal on the host and run:

```bash
multipass shell k8s-worker1
sudo kubeadm join <MASTER_IP>:6443 --token <TOKEN> --discovery-token-ca-cert-hash sha256:<HASH>
```

## 7) Verify

```bash
kubectl get nodes -o wide
kubectl get pods -A
```
