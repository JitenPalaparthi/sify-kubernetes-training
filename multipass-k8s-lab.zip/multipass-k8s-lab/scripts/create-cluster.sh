#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

multipass launch 24.04 --name k8s-master  --cpus 2 --memory 4G --disk 30G --cloud-init "$BASE_DIR/cloud-init/master.yaml"
multipass launch 24.04 --name k8s-worker1 --cpus 2 --memory 4G --disk 30G --cloud-init "$BASE_DIR/cloud-init/worker.yaml"
multipass launch 24.04 --name k8s-storage --cpus 2 --memory 2G --disk 40G --cloud-init "$BASE_DIR/cloud-init/storage.yaml"

echo
echo "Instances created. Check readiness with:"
echo "  multipass list"
echo "  multipass exec k8s-master -- cloud-init status --wait"
echo "  multipass exec k8s-worker1 -- cloud-init status --wait"
echo "  multipass exec k8s-storage -- cloud-init status --wait"
echo
echo "Then initialize the cluster using scripts/init-cluster.md"
