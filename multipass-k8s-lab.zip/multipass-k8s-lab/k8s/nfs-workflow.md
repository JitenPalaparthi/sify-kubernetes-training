# Static NFS volume workflow

1. Get the storage-node IP:

```bash
multipass info k8s-storage
```

2. Replace `REPLACE_WITH_NFS_SERVER_IP` in:
- `nfs-pv.yaml`
- `nfs-direct-pod.yaml`

3. Apply:

```bash
kubectl apply -f k8s/nfs-pv.yaml
kubectl apply -f k8s/nfs-pvc.yaml
kubectl apply -f k8s/nfs-test-pod.yaml
```

4. Verify:

```bash
kubectl get pv
kubectl get pvc
kubectl get pods -o wide
```

5. Write a file:

```bash
kubectl exec -it nfs-test -- sh -c 'echo hello-from-kubernetes > /data/test.txt'
```

6. Verify on the storage VM:

```bash
multipass exec k8s-storage -- ls -l /srv/nfs/kubedata
```
