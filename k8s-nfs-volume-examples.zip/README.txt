Kubernetes NFS Volume Examples

1. Replace REPLACE_WITH_NFS_SERVER_IP with your storage node IP.

Apply in order:

kubectl apply -f nfs-pv.yaml
kubectl apply -f nfs-pvc.yaml
kubectl apply -f nfs-test-pod.yaml

Verify:
kubectl get pv
kubectl get pvc
kubectl get pods -o wide

Write test file:
kubectl exec -it nfs-test -- sh
echo hello > /data/test.txt

Verify on NFS server:
ls /srv/nfs/kubedata

Direct NFS mount test:
kubectl apply -f nfs-direct-pod.yaml
